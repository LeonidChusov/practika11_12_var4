package com.example.practika12_var4

data class odejda(
    var temperature: String, var city: String, var date: String, var month: String, var year: String){
}